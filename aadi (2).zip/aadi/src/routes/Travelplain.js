import Travelplain1 from "../Components/Travelplain1";
import Footer from "../Components/Footer";
import Contact1 from "../Components/Contact1";
import Ads from "../Components/Ads";


 function Travelplain() {
  return (
    <div>
      <Contact1/>
      <Travelplain1/>
      <Ads/>
      <Footer/>
    </div>
  )
}

export default Travelplain;


