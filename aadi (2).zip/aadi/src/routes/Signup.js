import React from 'react'
//import Form from '../Components/Form'


function Signup() {
  return (
    <>
    {/* <Form/> */}
    </>
  )
}

export default Signup
