import React from 'react'

function Price4() {
  return (
    <div>
      <h1>hii3</h1>
    </div>
  )
}

export default Price4
