import React from 'react'

function Price3() {
  return (
    <div>
      <h1>hii</h1>
    </div>
  )
}

export default Price3
