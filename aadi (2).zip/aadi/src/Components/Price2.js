import React from 'react'

function Price2() {
  return (
    <div>
      <h1>hii</h1>
    </div>
  )
}

export default Price2
