import "./Form.css"
import LoginSignupContainer from "./LoginSignupContainer/LoginSignupContainer"

function Form() {
  return (
    <>
    <LoginSignupContainer/>
    </>
  )
}

export default Form
