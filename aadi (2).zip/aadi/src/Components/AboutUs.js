import "./AboutUsStyles.css"

function AboutUs () {
    return(
        <div className="about-container">
            <h1>MA Travel.</h1>
            <p>Travel is the main thing you purchase that makes you more extravagant”. We, at MA Travel swear by this and put stock in satisfying travel dreams that make you perpetually rich constantly.Through our exceptionally curated occasion bundles, we need to take you on an adventure where you personally enjoy the stunning magnificence of World and far-off terrains. We need you to observe sensational scenes that are a long way past your creative ability.</p>

            <h1>Our team.</h1>
            <p>Our team has been great work together and we gives a best deal to everyone and we are helpfull on every ways and also give a best deal in hotetals and try to fullfill all the demans of people what he wants</p>
        </div>
    );
}

export default AboutUs