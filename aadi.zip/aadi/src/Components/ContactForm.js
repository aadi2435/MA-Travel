import "./ContactFormStyles.css";

function ContactForm() {
    return (
        <section id="contact">
        <div className="form-container">

            <h1>Send a message to us!</h1>
            <form action="https://formsubmit.co/aadia2435@gmail.com"  method='post'>
                <input placeholder="Name" />
                <input placeholder="Email" />
                <input placeholder="Subject" />
                <textarea placeholder="Message" rows="4"></textarea>
                <button>Send Message</button>
            </form>
        </div>
        <div className="map">
        <iframe
            title="This is a unique title"
            src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3670.188545534782!2d72.53277091415195!3d23.090192819593497!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x395e833aff168119%3A0x93171eb07d08285!2sSilver%20Oak%20College%20Of%20Engineering%20And%20Technology%20Class%20Room%2C%20Gota%2C%20Ahmedabad%2C%20Gujarat%20380081!5e0!3m2!1sen!2sin!4v1679244627247!5m2!1sen!2sin"
            width={600}
            height={450}
            style={{ border: 0 }}
            allowFullScreen=""
            loading="lazy"
            referrerPolicy="no-referrer-when-downgrade"
          />

        </div>
        </section>
        

    );
}

export default ContactForm